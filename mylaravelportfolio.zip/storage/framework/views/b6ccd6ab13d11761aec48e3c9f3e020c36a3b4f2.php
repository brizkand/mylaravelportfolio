<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name='author' content='Kevin Holgado'>
        <title>Laravel</title>
        
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        
        <link rel="stylesheet" href="<?php echo e(asset('mdb_boothack/css/bootstrap.min.css')); ?>">
        
        <link rel="stylesheet" href="<?php echo e(asset('mdb_boothack/css/mdb.min.css')); ?>">
    </head>
    <body>
        <?php echo e($home->name); ?>

        
        <!-- Footer -->

        
        
        <script type="text/javascript" src="<?php echo e(asset('mdb_boothack/js/jquery-3.3.1.min.js')); ?>"></script>
        
        <script type="text/javascript" src="<?php echo e(asset('mdb_boothack/js/popper.min.js')); ?>"></script>
        
        <script type="text/javascript" src="<?php echo e(asset('mdb_boothack/js/bootstrap.min.js')); ?>"></script>
        
        <script type="text/javascript" src="<?php echo e(asset('mdb_boothack/js/mdb.min.js')); ?>"></script>
        
        <script>
            // object-fit polyfill run
            objectFitImages();
            /* init Jarallax */
            jarallax(document.querySelectorAll('.jarallax'));
            jarallax(document.querySelectorAll('.jarallax-keep-img'), {
                keepImg: true,
            });
        </script>

        <script>
            new WOW().init();
        </script>
    </body>
</html>