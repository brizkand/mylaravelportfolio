<?php $__env->startSection('content'); ?>
<h1 class='h1-responsive font-weight-bold indigo-text text-center my-5 wow animated flipInX slower'>Gallery</h1>

<div class='row'>
    <div class='col-md-6 wow animated slow slideInLeft'>
        <?php echo $__env->make('includes.carousel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <div class='col-md-6'>
        <div class='row justify-content-md-center'>
            <?php $__currentLoopData = $gallery_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class='col-md-4'>
                    <!-- Card -->
                    <div class="card card-cascade wider reverse delay-1s <?php echo e($gallery->row_columns); ?>">
                        <div class="view overlay zoom">
                            <img class="card-img-top" src="/storage/gallery_images/<?php echo e($gallery->image); ?>" alt="<?php echo e($gallery->image); ?>">
                            <div class="mask flex-center">
                                <p class="black-text">See description</p>
                                <a href="/gallery/<?php echo e($gallery->id); ?>">
                                    <div class="mask rgba-blue-slight"></div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <!-- Card -->
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>